#!/usr/bin/env python3
"""Void Room handheld adaptation."""

from __future__ import annotations

import sys
import time
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE), str(HERE.parent / "_shared")]
from noir_runtime import CYAN, DIM, GREEN, MUTED, RED, TEXT, AmbientLoop, BaseApp, Surface, run_app, wrap_text


class VoidRoom(BaseApp):
    app_id = "void-room"
    title = "Void Room"
    durations = [5, 15, 30, 45, 60]
    sounds = ["Silence", "Rain", "Static"]

    def __init__(self):
        super().__init__()
        state = self.load_json("state.json", {})
        self.minutes = state.get("minutes", 15)
        self.no_exit = state.get("no_exit", False)
        self.no_backspace = state.get("no_backspace", False)
        self.sound = state.get("sound", 0)
        self.archive = self.load_json("archive.json", [])
        self.audio = AmbientLoop(self.data_dir)
        self.mode = "home"
        self.text = ""
        self.remaining = self.minutes * 60
        self.end_at = 0.0

    def persist(self):
        self.save_json("state.json", {"minutes": self.minutes, "no_exit": self.no_exit, "no_backspace": self.no_backspace, "sound": self.sound})

    def enter_room(self):
        self.mode = "room"
        self.text = ""
        self.remaining = self.minutes * 60
        self.end_at = time.monotonic() + self.remaining
        self.audio.play(self.sounds[self.sound].lower())

    def save_and_leave(self, completed=False):
        self.audio.stop()
        if self.text.strip():
            self.archive.insert(0, {
                "at": datetime.now().strftime("%Y-%m-%d %H:%M"),
                "minutes": self.minutes,
                "words": len(self.text.split()),
                "completed": completed,
                "text": self.text,
            })
            self.archive = self.archive[:30]
            self.save_json("archive.json", self.archive)
        self.mode = "home"
        self.set_notice("The room opens. Session saved.")

    def tick(self, now):
        super().tick(now)
        if self.mode == "room":
            self.remaining = max(0, int(self.end_at - now + 0.99))
            if self.remaining == 0:
                self.save_and_leave(True)

    def handle_key(self, key, char="", pressed=True):
        if not pressed:
            return
        if self.mode == "room":
            if key == "escape":
                if self.no_exit:
                    self.set_notice("NO-EXIT mode. Type :exit to leave.", 3)
                else:
                    self.save_and_leave()
            elif key == "backspace":
                if not self.no_backspace:
                    self.text = self.text[:-1]
            elif key == "enter":
                self.text += "\n"
            elif char and char.isprintable() and len(self.text) < 5000:
                self.text += char
                if self.text.endswith(":exit"):
                    self.text = self.text[:-5]
                    self.save_and_leave()
            return
        if self.mode == "archive":
            if key in ("escape", "a"):
                self.mode = "home"
            return
        if key in ("q", "escape"):
            self.quit = True
        elif key in ("1", "2", "3", "4", "5"):
            self.minutes = self.durations[int(key) - 1]
        elif key == "x":
            self.no_exit = not self.no_exit
        elif key == "b":
            self.no_backspace = not self.no_backspace
        elif key == "s":
            self.sound = (self.sound + 1) % len(self.sounds)
        elif key in ("enter", "e", "space"):
            self.enter_room()
        elif key == "a":
            self.mode = "archive"
        self.persist()

    def on_exit(self):
        self.audio.stop()

    def render(self):
        s = Surface()
        self.shell(s, "VOID ROOM")
        if self.mode == "room":
            mins, secs = divmod(self.remaining, 60)
            s.text(310, 27, f"{mins:02}:{secs:02}", TEXT, 12, True, anchor="ne")
            s.text(8, 27, "WRITE. DO NOT EDIT." if self.no_backspace else "WRITE.", RED, 10, True)
            lines = wrap_text(self.text or "Start writing...", 50)[-9:]
            s.text(8, 48, "\n".join(lines), TEXT if self.text else DIM, 9)
            s.text(8, 151, f"{len(self.text.split())} words   ESC save/exit", MUTED, 8)
            return s
        if self.mode == "archive":
            s.text(8, 28, "VOID ARCHIVE", RED, 11, True)
            if not self.archive:
                s.text(8, 50, "The archive is empty.", MUTED, 9)
            for row, item in enumerate(self.archive[:6]):
                preview = item["text"].replace("\n", " ")[:25]
                s.text(8, 48 + row * 16, f'{item["at"][5:]} {item["words"]:>3}w {preview}', TEXT if row == 0 else MUTED, 8)
            s.text(8, 151, "A / ESC return", MUTED, 8)
            return s
        s.text(10, 31, "VOID ROOM", TEXT, 24, True)
        s.text(11, 60, "A distraction-free space for raw thought.", MUTED, 9)
        s.text(10, 84, "duration", MUTED, 9)
        for idx, minutes in enumerate(self.durations, start=1):
            selected = minutes == self.minutes
            s.text(76 + (idx - 1) * 45, 84, f"[{idx}]{minutes}", RED if selected else TEXT, 9, selected)
        s.text(10, 103, f"[x] no-exit: {'ON' if self.no_exit else 'off'}", RED if self.no_exit else MUTED, 9)
        s.text(168, 103, f"[b] no-backspace: {'ON' if self.no_backspace else 'off'}", RED if self.no_backspace else MUTED, 9)
        s.text(10, 119, f"[s] ambience: {self.sounds[self.sound]}", CYAN, 9)
        s.text(10, 136, "[OK/enter] START WRITING     [a] archive", GREEN, 9, True)
        s.text(10, 151, "Q quit", MUTED, 8)
        return s


if __name__ == "__main__":
    raise SystemExit(run_app(VoidRoom))
